Manhattan Plot for experiment https://easygwas.tuebingen.mpg.de/gwas/results/manhattan/view/a8c40b93-c776-49cd-81f4-e4f311926f44/ 
This link is only valid if the experiment was saved permanently!