Manhattan Plot for experiment https://easygwas.tuebingen.mpg.de/gwas/results/manhattan/view/75246b31-9fed-415c-bd3f-913010df5eae/ 
This link is only valid if the experiment was saved permanently!